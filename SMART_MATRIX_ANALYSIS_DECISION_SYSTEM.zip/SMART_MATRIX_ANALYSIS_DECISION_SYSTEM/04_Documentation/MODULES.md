# Module Mapping

| Planned Module | Implementation Location |
|---|---|
| Matrix Creation & Initialization | `01_Matrix_Class/Matrix.cpp` – constructor |
| Matrix Input | `01_Matrix_Class/Matrix.cpp` – `input()` |
| Matrix Display | `01_Matrix_Class/Matrix.cpp` – `display()` |
| Matrix Addition | `01_Matrix_Class/Matrix.cpp` – `operator+()` |
| Matrix Subtraction | `01_Matrix_Class/Matrix.cpp` – `operator-()` |
| Matrix Multiplication | `01_Matrix_Class/Matrix.cpp` – `operator*()` |
| Matrix Transpose | `01_Matrix_Class/Matrix.cpp` – `transpose()` |
| Scalar Multiplication | `01_Matrix_Class/Matrix.cpp` – `scalarMultiply()` |
| Determinant | `01_Matrix_Class/Matrix.cpp` – `determinant()` |
| Inverse | `01_Matrix_Class/Matrix.cpp` – `inverse()` |
| Matrix Analysis | `01_Matrix_Class/Matrix.cpp` – analysis functions and `analyze()` |
| Dimension/Input Validation | `03_Main_Menu/main.cpp` and matrix operators |
| Operation History | `02_Operation_History/OperationHistory.cpp` |
| Menu Interface | `03_Main_Menu/main.cpp` |

## Important

The project uses one `Matrix` class for all matrix-related operations. This avoids creating separate programs for each operation while still keeping the project organized into source modules.
