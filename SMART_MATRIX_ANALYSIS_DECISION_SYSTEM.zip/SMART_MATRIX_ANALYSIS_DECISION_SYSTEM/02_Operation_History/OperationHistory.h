#ifndef OPERATION_HISTORY_H
#define OPERATION_HISTORY_H

#include <iostream>
#include <string>

using namespace std;

class OperationHistory
{
private:
    string history[50];
    int count;

public:
    OperationHistory();
    void add(string operation);
    void display() const;
};

#endif
