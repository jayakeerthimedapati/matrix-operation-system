# SMART MATRIX ANALYSIS & DECISION SYSTEM

### An Object-Oriented C++ Matrix Processing and Analysis Tool

This repository contains the modular version of the team's existing C++ matrix project.

## Project Modules

1. **Matrix Creation & Input** – creates matrices and accepts elements.
2. **Matrix Display** – displays matrix elements in formatted form.
3. **Matrix Addition** – adds two matrices after dimension validation.
4. **Matrix Subtraction** – subtracts two matrices after dimension validation.
5. **Matrix Multiplication** – multiplies matrices when compatible dimensions are provided.
6. **Matrix Transpose** – generates the transpose of Matrix A.
7. **Scalar Multiplication** – multiplies Matrix A by a scalar value.
8. **Determinant** – calculates determinants for square matrices up to 3×3.
9. **Matrix Inverse** – calculates inverse for non-singular square matrices up to 3×3.
10. **Matrix Analysis** – checks square, symmetric, diagonal, identity, zero and sparse properties and calculates trace, maximum, minimum, sum and average.
11. **Dimension/Input Validation** – validates matrix sizes and operation requirements.
12. **Operation History** – records operations performed during the current program execution.
13. **Menu-Driven Interface** – connects all modules through the main menu.

## OOP Concepts Used

- Classes and objects
- Encapsulation
- Abstraction
- Constructors
- Member functions
- Operator overloading
- Arrays
- Loops and conditional statements

## Folder Structure

```text
SMART_MATRIX_ANALYSIS_DECISION_SYSTEM/
├── 01_Matrix_Class/
│   ├── Matrix.h
│   └── Matrix.cpp
├── 02_Operation_History/
│   ├── OperationHistory.h
│   └── OperationHistory.cpp
├── 03_Main_Menu/
│   └── main.cpp
├── 04_Documentation/
│   └── MODULES.md
├── README.md
└── .gitignore
```

## How to Compile

### Using Dev-C++

Open all five `.cpp/.h` files in the project and compile:

- `01_Matrix_Class/Matrix.cpp`
- `02_Operation_History/OperationHistory.cpp`
- `03_Main_Menu/main.cpp`

The include paths in `main.cpp` are already set for this folder structure.

### Using g++

From the project root:

```bash
g++ 01_Matrix_Class/Matrix.cpp 02_Operation_History/OperationHistory.cpp 03_Main_Menu/main.cpp -o SmartMatrix
```

Run:

```bash
./SmartMatrix
```

On Windows:

```text
SmartMatrix.exe
```

## Note

The modular structure reorganizes the existing project without adding a website or external libraries.
