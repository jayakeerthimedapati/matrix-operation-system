#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
#include <iomanip>

using namespace std;

class Matrix
{
private:
    int rows;
    int cols;
    int data[10][10];

public:
    Matrix(int r = 0, int c = 0);

    void input();
    void display() const;

    int getRows() const;
    int getCols() const;

    Matrix operator+(const Matrix& B) const;
    Matrix operator-(const Matrix& B) const;
    Matrix operator*(const Matrix& B) const;

    Matrix transpose() const;
    Matrix scalarMultiply(int value) const;

    bool isSquare() const;
    bool isSymmetric() const;
    bool isDiagonal() const;
    bool isIdentity() const;
    bool isZero() const;
    bool isSparse() const;

    int trace() const;
    int maximum() const;
    int minimum() const;
    int totalSum() const;

    double determinant() const;
    Matrix inverse() const;

    void analyze() const;
};

#endif
